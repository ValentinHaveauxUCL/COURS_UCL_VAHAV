#include <stdio.h>
#include <stdlib.h>
#include "packet_interface.h"

int main(int argc, const char *argv[])
{
  printf("I like train \n");
  return 0;
}
